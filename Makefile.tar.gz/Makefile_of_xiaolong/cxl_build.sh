#!/bin/bash
#run as below:
#   chmod 777 cxl_build.sh
#   ./cxl_build.sh or sh cxl_build.sh

echo "File name is :(needs only *,no (.c)) "
read filename
#echo "${filename}"
cp ${filename}.c arm${filename}.c 
make TARGETNAME=${filename}.o
make TARGETNAME=${filename}.o CONFIG_ARM=y
rm -rf arm${filename}.c
#make clean
#end

